Logowanie:
- przycisk "Loguj z FB" -> Raportowanie zgłoszenia
- przycisk "Loguj z Google" -> Raportowanie zgłoszenia
- przycisk "Loguj jako inspektor" -> Logowanie inspektora

Logowanie inspektora:
- login
- hasło
- loguj -> Dashboard

Dashboard:
- mapa z pinezkami zgłoszeń //jest XDDDDD
- przycisk "Dodaj zgłoszenie" -> Raportowanie zgłoszenia (inspektor)
- przycisk "lista zgłoszeń" -> Lista zgłoszeń
- wzorowane na google maps

Raportowanie zgłoszenia:
- formularz:
  - opis
  - numer telefonu
  - lokalizacja do wpisania
  - dodawanie i usuwanie załączników
- wyślij -> popup "Dziękujemy za zgłoszenie"

Raportowanie zgłoszenia (inspektor):
- tak samo jak w zwykłym, lecz można wybrać inną datę

Lista zgłoszeń:
- zgłoszenia:
  - data
  - miejsce
  - klikalne -> Zgłoszenie
- sortowane po dacie

Zgłoszenie:
- data
- kto zgłosił
- opis
- numer telefonu
- email
- status
- lokalizacja wyświetlona na mapie + tekstowo
- załączniki (lista z nazwami plików, do pobrania)
- komentarze
- możliwość wpisania komentarza
- przycisk edytuj -> Edycja zgłoszenia

Edycja zgłoszenia:
- wszystkie pole zgłoszenia do edycji oprócz osoby zgłaszającej
- nie wyświetlamy tylko komentarzy